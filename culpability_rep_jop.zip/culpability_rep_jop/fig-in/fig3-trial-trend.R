
trials_plot <- read.csv("data/trials_data_FOR_ANALYSIS.csv", header = T) %>%   
  mutate(life_sentence = as.numeric(defendant_outcome=="life", 1,0)) %>% 
  group_by(year) %>% 
  summarise(
    life_sentence = sum(life_sentence, na.rm = T),
    noconvict = sum(noconvict, na.rm = T),
    n_trial = n()
  ) %>%
  mutate(convict = n_trial-noconvict, 
         notlife = convict-life_sentence) %>% 
  ggplot(group = year) + 
  geom_line(mapping = aes(year, noconvict, linetype = "Non-Convictions", 
                          color = "Non-Convictions"), 
            size = 1) + 
  geom_line(mapping = aes(year, life_sentence, linetype = "Life Sentences", 
                          color = "Life Sentences"),
            size = 1) + 
  geom_line(mapping = aes(year, convict, linetype = 'Convictions', 
                          color  = "Convictions"),
            size = 1) + 
  geom_line(mapping = aes(year, notlife, linetype = 'Conviction Short of Life', 
                          color  = "Conviction Short of Life"),
            size = 1) + 
  scale_x_continuous(breaks = seq(2005, 2017, 1)) + 
  xlab('Year') + 
  ylab('Count') + 
  labs(lty = '', color = '') + 
  theme_minimal() +
  theme(legend.position = 'bottom') + 
  theme(text=element_text(size=20))

ggsave("fig-out/trials_plot2.pdf", trials_plot)