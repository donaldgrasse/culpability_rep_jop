
repression_plot_one = readRDS('data/officer_df.rds') %>%  
  filter(is.na(outcomes) == F) %>% 
  filter(die == 0) %>%  
  mutate(years_na = as.numeric(is.na(mean_sentence) == T)) %>% 
  filter(years_na == 0) %>%  
  mutate(repression_std = as.numeric(scale(repression_std)), 
         repress_cut = cut(repression_std, 10)) %>%  
  group_by(repress_cut) %>%  
  mutate(sentence_ag = mean(mean_sentence, na.rm = T), 
         repression_std = mean(repression_std, na.rm = T)) %>%  
  ggplot(., aes(repression_std, sentence_ag)) + 
  geom_point() + 
  geom_smooth(method = 'lm') + 
  theme_bw() + xlab('Repression Culpability (Standardized)') + 
  ylab('Average Sentence Length (Years)') + 
  theme(text = element_text(size = 20))
ggsave('fig-out/sentence_yrs_on_repression_culp.pdf')

