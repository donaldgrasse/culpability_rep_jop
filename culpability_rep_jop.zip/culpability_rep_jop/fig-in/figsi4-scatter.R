
scatter_all = readRDS('data/officer_df.rds') %>%  
  filter(is.na(outcomes) == F) %>% 
  filter(die == 0) %>%  
  mutate(years_na = as.numeric(is.na(mean_sentence) == T)) %>% 
  filter(years_na == 0) %>% 
  ggplot(., aes(repression_std, mean_sentence)) + 
  geom_point() + geom_smooth(method = 'lm') + 
  theme_bw() + xlab('Repression Culpability (Standardized)') + 
  ylab('Average Sentence Length (Years)') + 
  theme(text = element_text(size = 20))
ggsave('fig-out/scatter_all.pdf')



