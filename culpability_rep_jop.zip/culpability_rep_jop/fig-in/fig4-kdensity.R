


kernel_density = ggplot(readRDS('data/trial_clean.rds'), aes(sentence_yr)) + 
  geom_density() +
  xlab('Years of Sentence') + 
  ylab('Kernel Density') + 
  theme_minimal() + 
  theme(axis.text=element_text(size=12), 
        axis.title=element_text(size=14))
ggsave('fig-out/sentence_kernel_density.pdf')
