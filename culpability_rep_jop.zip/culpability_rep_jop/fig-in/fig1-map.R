
gadm_shp <- read_sf(dsn  = 'data/ARG_adm/ARG_adm2.shp') %>%  
  mutate(zone1 = as.numeric(NAME_1 %in% c('Ciudad de Buenos Aires', 'La Pampa') | 
                              (NAME_1 == 'Buenos Aires' & !(NAME_2 %in% c(
                                "Adolfo Alsina", "Guaminí", 
                                "Coronel Suárez", "Saavedra", "Puán", 
                                "Tornquist", 
                                "Coronel Pringles", "Adolfo Gonzales Chaves", 
                                "Coronel Dorrego", 
                                "Tres Arroyos", 
                                "Villarino", "Bahía Blanca", "Patagones", 
                                "San Fernando", 
                                'Coronel de Marina Leonardo Rosales',
                                'Monte Hermoso', 
                                'Escobar', 'General San Martín', 
                                'General Sarmiento', 'Pilar',
                                'San Fernando (1)', 'San Fernando (2)', 
                                'Tigre', 'Tres de Febrero', 
                                'Vicente López')
                              ))), 
         
         
         zone2 = as.numeric(NAME_1 %in% c('Santa Fe', 'Entre Ríos', 
                                          'Corrientes', 'Misiones', 'Chaco', 
                                          'Formosa')), 
         
         zone3 = as.numeric(NAME_1 %in% c('Córdoba', 'San Luis', 'Mendoza', 
                                          'San Juan', 'La Rioja', 'Catamarca', 
                                          'Santiago del Estero', 'Tucumán', 'Salta', 'Jujuy')), 
         
         zone4 = as.numeric(NAME_1 == 'Buenos Aires' & NAME_2 %in%  c(
           'Escobar', 'General San Martín', 'General Sarmiento', 'Pilar',
           'San Fernando (1)', 'San Fernando (2)', 'Tigre', 'Tres de Febrero', 
           'Vicente López')), 
         zone5 = as.numeric(NAME_1 %in% c('Neuquén', 'Río Negro', 'Chubut', 'Santa Cruz', 
                                          'Tierra del Fuego') | 
                              NAME_1 == 'Buenos Aires' & NAME_2 %in% 
                              c("Adolfo Alsina", "Guaminí", 
                                "Coronel Suárez", "Saavedra", "Puán", "Tornquist", 
                                "Coronel Pringles", "Adolfo Gonzales Chaves", "Coronel Dorrego", 
                                "Tres Arroyos", 
                                "Villarino", "Bahía Blanca", "Patagones", 
                                "San Fernando", 
                                'Coronel de Marina Leonardo Rosales',
                                'Monte Hermoso')
                            
         ), 
         
         zone = case_when(
           zone1 == 1 ~ "Zone 1",
           zone2 == 1 ~ "Zone 2",
           zone3 == 1 ~ "Zone 3",
           zone4 == 1 ~ "Zone 4",
           zone5 == 1 ~ "Zone 5"
         )
  )


BigMap = tm_shape(gadm_shp) + tm_fill('zone', title = 'Zone')  + 
  tm_layout(frame = FALSE)
SmallMap <- tm_shape(gadm_shp %>%  filter(zone == 'Zone 4') %>%  
                       mutate(zone = ifelse(NAME_2 == 'Pilar', zone, NA))) + 
  tm_fill() + tm_text('zone', size = 1)
BigMap
print(SmallMap, vp = viewport(0.8, .8, width = 0.25, height = 0.25))



cs_map = merge(gadm_shp, 
               readRDS('data/processo_panel.rds') %>%  
                 group_by(ID_2) %>%  
                 summarise(repress=sum(repress)),
               by = 'ID_2')
cs_map = cs_map %>%  
  mutate(repress_groups = case_when(
    repress == 0 ~ '0', 
    repress > 0 & repress <= 1 ~ '1', 
    repress > 1 & repress <=3 ~ '1-3', 
    repress > 3 & repress <=20 ~ '3-20',
    repress > 20 ~ "20-1974"
  ), 
  repress_groups = fct_relevel(repress_groups,  c("0", "1", "1-3", '3-20', '20-1974')))


MyPalette <- c("#d1e5f0", "#a6bddb", "#67a9cf", "#1c9099", "#016c59")


ARG_map = tm_shape(cs_map) + tm_fill('repress_groups', palette = MyPalette, 
                                     title = 'Total Repression')  + 
  tm_layout(frame = FALSE)
BA = cs_map %>%  
  filter(NAME_1 == 'Buenos Aires')

BA_map = tm_shape(BA) + tm_polygons('repress_groups', palette = MyPalette, 
                                    title = 'Total Repression')  + 
  tm_layout(frame = FALSE)

arg_map = tmap_arrange(ARG_map, BA_map)
tmap_save(arg_map, 'fig-out/arg_map.pdf')