
df = readRDS('data/officer_df.rds') %>%  
  filter(is.na(outcomes) == F) %>% 
  filter(die == 0) %>%  
  mutate(years_na = as.numeric(is.na(mean_sentence) == T)) %>% 
  filter(years_na == 0) %>%  
  mutate(repress_scale = scale(repression_std))


reg_list = as.numeric()
se_list = as.numeric()

for(i in 1:nrow(df)){
  reg_list[i] = lm_robust(mean_sentence ~ repress_scale + 
                         factor(maxrank) + factor(maxlevel) + tenure + officer_branch, 
                       data = df[-i,])$coef[2]
  se_list[i] = lm_robust(mean_sentence ~ repress_scale + 
                            factor(maxrank) + factor(maxlevel) + tenure + officer_branch, 
                          data = df[-i,])$std.error[2]
}

figsi2 = cbind.data.frame(est = reg_list, se = se_list) %>%  
  mutate(ci_h = est + 1.96*se, 
         ci_l = est - 1.96*se, 
         n = cur_group_rows()) %>% 
  ggplot(., aes(est, n)) + 
  geom_point() + 
  geom_vline(xintercept = 0) + 
  geom_errorbar(aes(xmin = ci_l, xmax = ci_h)) + 
  xlab('Estimate') + ylab('Officer Dropped') + 
  theme_minimal() + 
  geom_vline(xintercept = 2.432103, col = 'red', lty = 2) +
  geom_vline(xintercept = 10.062453, col = 'red', lty = 2) +
  theme(text = element_text(size = 20))

ggsave('fig-out/figsi2.pdf')
