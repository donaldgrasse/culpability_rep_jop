
#### Officer Level Results #### 
df = readRDS('data/officer_df.rds') %>%  
  filter(is.na(outcomes) == F) %>% 
  filter(die == 0) %>%  
  mutate(years_na = as.numeric(is.na(mean_sentence) == T)) %>% 
  filter(years_na == 0)


#### any contact #### 
df = df %>%  
  mutate(contact_system = as.numeric(free == 0))

m1 = feols(contact_system ~ repression_std + changed_ever + (factor(maxrank) + factor(maxlevel) + tenure + officer_branch), 
           data = df)
m2 = feols(contact_system ~ changed_ever + factor(maxrank) + factor(maxlevel) + tenure + officer_branch |0| 
             scale(repression_std)  ~ I(first_year_served<=1978), df)
writeLines(etable(m1, m2, tex = T), 
           'tab-out/tabSI5-contact.tex')

