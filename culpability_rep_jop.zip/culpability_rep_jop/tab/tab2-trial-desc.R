
trial_outcome_table = readRDS('data/trial_clean.rds') %>% 
  filter(is.na(presiding_judge_appt_pres) == F) %>% 
  group_by(presiding_judge_appt_pres) %>%  
  summarise(sentence_yr_mean = mean(sentence_yr, na.rm = T), 
            sd = sd(sentence_yr, na.rm = T),
            n_judges = n())

writeLines(print(xtable(trial_outcome_table), include.rownames = F), 
           'tab-out/tab2-trial-desc.tex')
