df = readRDS('data/officer_df.rds') %>%  
  filter(is.na(outcomes) == F) %>% 
  filter(die == 0) %>%  
  mutate(years_na = as.numeric(is.na(mean_sentence) == T)) %>% 
  filter(years_na == 0)

m1 = feols(c(max_sentence, mean_sentence, life) ~ scale(totalrepression) + tenure + officer_branch+ changed_ever + factor(maxrank) + factor(maxlevel) + officer_branch, 
           data = df)

m2 = feols(c(max_sentence, mean_sentence, life) ~ scale(asinh(totalrepression)) + tenure + officer_branch+ changed_ever + factor(maxrank) + factor(maxlevel) + officer_branch, 
           data = df)
m3 = feols(c(max_sentence, mean_sentence, life) ~ scale(log(totalrepression+1)) + tenure + officer_branch+ changed_ever + factor(maxrank) + factor(maxlevel) + officer_branch, 
           data = df)

writeLines(etable(m1, m2, m3, tex = T), 
          'tab-out/tabSI4.tex') 


etable(m1, tex = T)
etable(m2, tex = T)
etable(m3, tex = T)
