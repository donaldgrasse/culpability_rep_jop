
#1. data cleaning####

trial <- read.csv('data/trials_data_FOR_ANALYSIS.csv', header = T)
trial$defendant_birth_year[trial$defendant_ID==806] <- 1947
trial$life_sentence <- as.numeric(trial$defendant_outcome=="life", 1,0)
trial$presiding_judge_appt_pres <- relevel(as.factor(trial$presiding_judge_appt_pres), 
                                           ref = 'Carlos Menem')

#3. robustness tests####

#### (a) pre-post 1998 appointments (de jure)####

substrRight <- function(x, n){
  substr(x, nchar(x)-n+1, nchar(x))
}

trial$presiding_judge_appt_year <- substrRight(trial$presiding_judge_datefirstappt, 4)
trial$presiding_judge_nojc <- ifelse(trial$presiding_judge_appt_year < 1998,1,0)
trial$presiding_judge_nojc[is.na(trial$presiding_judge_appt_year)] <- NA


r1 <- lm_robust(noconvict ~ presiding_judge_nojc + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

r2 <- lm_robust(life_sentence ~ presiding_judge_nojc + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

#### (b) appointed at time of unified peronist control (de jure)####

trial$presiding_judge_datefirstappt <- as.Date(trial$presiding_judge_datefirstappt, format = "%m/%d/%Y")

trial$presiding_judge_pjjc <- 0 
trial$presiding_judge_pjjc[is.na(trial$presiding_judge)] <- NA
trial$presiding_judge_pjjc[trial$presiding_judge_datefirstappt > as.Date("2003-12-10") 
                           & trial$presiding_judge_datefirstappt < as.Date("2009-12-10")] <- 1
trial$presiding_judge_pjjc[trial$presiding_judge_datefirstappt > as.Date("2013-12-10") 
                           & trial$presiding_judge_datefirstappt < as.Date("2015-12-10")] <- 1


r3 <- lm_robust(noconvict ~ presiding_judge_pjjc + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

r4 <- lm_robust(life_sentence ~ presiding_judge_pjjc + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

texreg::screenreg(list(r1, r2, r3, r4), include.ci = F, 
                  'tab-out/tabSI8.tex')