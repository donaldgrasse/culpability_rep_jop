
df = readRDS('data/officer_df.rds') %>%  
  filter(is.na(outcomes) == F) %>% 
  filter(die == 0) %>%  
  mutate(years_na = as.numeric(is.na(mean_sentence) == T)) %>% 
  filter(years_na == 0) %>% 
  mutate(max_lvl = factor(ifelse(max_sentence == 0, '0', 
                          ifelse(max_sentence == 50, '1', '.5')
                          )), 
         mean_lvl = factor(ifelse(mean_sentence == 0, '0', 
                          ifelse(mean_sentence == 50, '1', '.5'))
         ), 
         ) %>%  
  as.data.frame()   
  

df$mean_lvl = relevel(df$mean_lvl, ref = '0')
df$max_lvl = relevel(df$max_lvl, ref = '0')

m1 = MASS::polr(max_lvl ~ scale(repression_std) + 
       factor(maxrank) + factor(maxlevel) + tenure + officer_branch, 
     data = df, Hess=TRUE)

m2 = MASS::polr(mean_lvl ~ scale(repression_std) + 
            factor(maxrank) + factor(maxlevel) + tenure + officer_branch, 
          data = df, Hess=TRUE)

m3 = glm(life ~ scale(repression_std) + 
            factor(maxrank) + factor(maxlevel) + tenure + officer_branch, 
          data = df, family = 'binomial')
texreg::screenreg(list(m1, m2, m3), include.ci = F, 
                  'tab-out/tabSI7-logit.tex')
