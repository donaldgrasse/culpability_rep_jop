pgks = c('dplyr', 'tidyverse', 'fixest')
lapply(pgks, require, character.only = T)

#### Officer Level Results #### 
df = readRDS('data/officer_df.rds') %>%  
  filter(is.na(outcomes) == F) %>% 
  filter(die == 0) %>%  
  mutate(years_na = as.numeric(is.na(mean_sentence) == T)) %>% 
  filter(years_na == 0)

writeLines(etable(feols(c(max_sentence, mean_sentence, life) ~ scale(repression_std) + 
                          factor(maxrank) + factor(maxlevel) + tenure + officer_branch, 
                        data = df),tex = TRUE), "tab-out/tab1-ols.tex")

writeLines(etable(feols(c(max_sentence, mean_sentence, life) ~ factor(maxrank) + factor(maxlevel) + tenure + officer_branch
             | 0 |scale(repression_std)  ~ I(first_year_served<=1978) , df),tex = TRUE), 
            "tab-out/tab1-2sls.tex")

