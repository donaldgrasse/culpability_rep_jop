officer = readRDS('data/officer_df.rds') 
#4. descriptive statistics ####
library(xtable)

desc.stats <- function(var){
  stats <- vector(mode="numeric")
  stats[1] <- round(min(var, na.rm=T),2)
  stats[2] <- round(max(var, na.rm=T),2)
  stats[3] <- round(mean(var, na.rm=T),2)
  stats[4] <- round(median(var, na.rm=T),2)
  stats[5] <- round(sd(var, na.rm=T),2)
  stats[6] <- sum(ifelse(is.na(var),1,0))
  return(stats)}

desc.stats <- as.data.frame(
  cbind(c("Living Free","Life Sentence","Repression", "Served Before 1978",
          "Max Sentence", "Cum. Sentence",
          "Ordinal Rank", "Duration of Control"),
        rbind(
          desc.stats(officer$die),
          desc.stats(officer$life),
          desc.stats(officer$repression_std),
          desc.stats(as.numeric(officer$first_year_served<=1977, 1,0)),
          desc.stats(officer$max_sentence),
          desc.stats(officer$cum_sentence),
          desc.stats(officer$maxrank),
          desc.stats(as.numeric(officer$last_year_served - officer$first_year_served)) )))

colnames(desc.stats) <- c("Variable","Minimum","Maximum","Mean","Median","Std. Dev","Missing")

writeLines(
  print(xtable(desc.stats, caption="Descriptive Statistics, Officer Level"), include.rownames=FALSE), 
  'tab-out/tabS1-desc.tex'
)
