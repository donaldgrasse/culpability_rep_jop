
#### Officer Level Results #### 
df = readRDS('data/officer_df.rds') %>%  
  filter(is.na(outcomes) == F) %>% 
  filter(die == 0) %>%  
  mutate(years_na = as.numeric(is.na(mean_sentence) == T)) %>% 
  filter(years_na == 0)


df = readRDS('data/officer_df.rds') %>%  
  filter(is.na(outcomes) == F) %>% 
  filter(die == 0) %>%  
  mutate(years_na = as.numeric(is.na(mean_sentence) == T)) %>% 
  filter(years_na == 0) %>%  
  left_join(., read.csv('data/officer_trial_merge.csv', 
                        header = T) %>% 
              group_by(officer_name) %>%  
              summarise(ntrial=n()), 
            by = 'officer_name'
  ) %>%  
  mutate(ntrial = ifelse(is.na(ntrial) == T,  0, ntrial)) %>%  
  left_join(., read.csv('data/officer_trial_merge.csv', 
                        header = T) %>% 
              group_by(officer_name) %>%  
              mutate(min_year = min(year)) %>%  
              filter(year == min_year) %>% 
              mutate(first_sentence = sentence_yr) %>%  
              dplyr::select(officer_name, first_sentence) %>%  
              group_by(officer_name) %>% 
              summarise(first_sentence = mean(first_sentence, na.rm = T)), 
            by = 'officer_name'
  ) %>%  
  mutate(first_sentence = if_else(is.na(first_sentence) == T, 0, first_sentence), 
         first_life = ifelse(first_sentence == 50, 1,0))

writeLines(etable(feols(c(first_sentence, first_life)~ scale(repression_std) + 
               factor(maxrank) + factor(maxlevel) + tenure + officer_branch, 
             data = df),tex = TRUE), 
           'tab-out/tabSI6-panelA.tex')

writeLines(etable(feols(c(cum_sentence, life) ~ scale(repression_std) + 
               factor(maxrank) + factor(maxlevel) + tenure + officer_branch, 
             data = df %>%  
               filter(ntrial <= 1)),tex = TRUE), 
           'tab-out/tabSI6-panelB.tex'       
)

