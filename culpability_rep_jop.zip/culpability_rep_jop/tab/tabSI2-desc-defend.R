packs <- c('dplyr', 'estimatr', 'texreg', 'stringr', 'ggplot2', 'ggthemes')
lapply(packs, require, character.only = T)

#1. data cleaning####

trial <- read.csv('data/trials_data_FOR_ANALYSIS.csv', header = T)
trial$defendant_birth_year[trial$defendant_ID==806] <- 1947
trial$life_sentence <- as.numeric(trial$defendant_outcome=="life", 1,0)
trial$presiding_judge_appt_pres <- relevel(as.factor(trial$presiding_judge_appt_pres), 
                                           ref = 'Carlos Menem')

#2. main results####

m1 <- lm_robust(defendant_age ~ presiding_judge_appt_pres + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

m2 <- lm_robust(noconvict ~ presiding_judge_appt_pres + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

m3 <- lm_robust(life_sentence ~ presiding_judge_appt_pres + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

texreg::texreg(list(m1, m2, m3), include.ci = F)


abc = trial %>%  
  group_by(defendant_name) %>% 
  summarise(n = n())


#3. robustness tests####

#### (a) pre-post 1998 appointments (de jure)####

substrRight <- function(x, n){
  substr(x, nchar(x)-n+1, nchar(x))
}

trial$presiding_judge_appt_year <- substrRight(trial$presiding_judge_datefirstappt, 4)
trial$presiding_judge_nojc <- ifelse(trial$presiding_judge_appt_year < 1998,1,0)
trial$presiding_judge_nojc[is.na(trial$presiding_judge_appt_year)] <- NA


r1 <- lm_robust(noconvict ~ presiding_judge_nojc + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

r2 <- lm_robust(life_sentence ~ presiding_judge_nojc + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

#### (b) appointed at time of unified peronist control (de jure)####

trial$presiding_judge_datefirstappt <- as.Date(trial$presiding_judge_datefirstappt, format = "%m/%d/%Y")

trial$presiding_judge_pjjc <- 0 
trial$presiding_judge_pjjc[is.na(trial$presiding_judge)] <- NA
trial$presiding_judge_pjjc[trial$presiding_judge_datefirstappt > as.Date("2003-12-10") 
                           & trial$presiding_judge_datefirstappt < as.Date("2009-12-10")] <- 1
trial$presiding_judge_pjjc[trial$presiding_judge_datefirstappt > as.Date("2013-12-10") 
                           & trial$presiding_judge_datefirstappt < as.Date("2015-12-10")] <- 1


r3 <- lm_robust(noconvict ~ presiding_judge_pjjc + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

r4 <- lm_robust(life_sentence ~ presiding_judge_pjjc + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

texreg::texreg(list(r1, r2, r3, r4), include.ci = F)

#### (c) pre-post Macri presidency verdict date (de facto)####

trial$under_macri <- ifelse(trial$trial_ID > 151,1,0)

r1 <- lm_robust(noconvict ~ under_macri + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

r2 <- lm_robust(life_sentence ~ under_macri + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

#### (d) monthly Kirchner approval rating (de facto)####

trial$final_date <- as.Date(trial$final_date, format = "%m/%d/%Y")
trial$final_date_monthyr <- format(trial$final_date, "%Y-%m")
trial$final_date_monthyr <- as.character(trial$final_date_monthyr)

approve <- read.csv("data/EAD 3.0 Monthly_11282023.csv")
approve <- subset(approve, approve$country_name == "Argentina")

approve$year <-  substring(approve$monthly, 1, 4)
approve$month <- substrRight(approve$monthly, 2)
approve$month <- gsub("[^0-9.-]", "", approve$month)
for(i in 1:nrow(approve)){
  approve$month[i] <- ifelse(nchar(approve$month[i]) == 1, paste(0, approve$month[i], sep=""), approve$month[i])}

approve$final_date_monthyr <- paste(approve$year, approve$month, sep="-")

trial <- merge(trial,approve, by="final_date_monthyr", all.x=TRUE)

trial$under_kirchner = 1 - trial$under_macri

r3 <- lm_robust(noconvict ~ under_kirchner*Approval_Smoothed + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year.x, 
                clusters = trial_ID)

r4 <- lm_robust(life_sentence ~ under_kirchner*Approval_Smoothed + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year.x, 
                clusters = trial_ID)

texreg::texreg(list(r1, r2, r3, r4), include.ci = F)



#4. descriptive statistics ####
library(xtable)

desc.stats <- function(var){
  stats <- vector(mode="numeric")
  stats[1] <- round(min(var, na.rm=T),2)
  stats[2] <- round(max(var, na.rm=T),2)
  stats[3] <- round(mean(var, na.rm=T),2)
  stats[4] <- round(median(var, na.rm=T),2)
  stats[5] <- round(sd(var, na.rm=T),2)
  stats[6] <- sum(ifelse(is.na(var),1,0))
  return(stats)}

desc.stats <- as.data.frame(
  cbind(c("No Conviction","Life Sentence","Defendant Age", "Macri-Era Verdict",
          "Kirchner Appointee", "Pre-Judicial Council",
          "Unified Peronist Control", "Executive Approval"),
        rbind(
          desc.stats(trial$noconvict),
          desc.stats(trial$life_sentence),
          desc.stats(trial$defendant_age),
          desc.stats(trial$under_macri),
          desc.stats(trial$under_kirchner),
          desc.stats(trial$presiding_judge_nojc),
          desc.stats(trial$presiding_judge_pjjc),
          desc.stats(trial$Approval_Smoothed) )))

colnames(desc.stats) <- c("Variable","Minimum","Maximum","Mean","Median","Std. Dev","Missing")

writeLines(
print(xtable(desc.stats, caption="Descriptive Statistics, Trial Level"), include.rownames=FALSE), 
'tab-out/tabS12-desc.tex'
)
