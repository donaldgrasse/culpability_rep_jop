
#1. data cleaning####

trial <- read.csv('Data/trials_data_FOR_ANALYSIS.csv', header = T)
trial$defendant_birth_year[trial$defendant_ID==806] <- 1947
trial$life_sentence <- as.numeric(trial$defendant_outcome=="life", 1,0)
trial$presiding_judge_appt_pres <- relevel(as.factor(trial$presiding_judge_appt_pres), 
                                           ref = 'Carlos Menem')

#### (c) pre-post Macri presidency verdict date (de facto)####

trial$under_macri <- ifelse(trial$trial_ID > 151,1,0)

r1 <- lm_robust(noconvict ~ under_macri + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

r2 <- lm_robust(life_sentence ~ under_macri + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

#### (d) monthly Kirchner approval rating (de facto)####

trial$final_date <- as.Date(trial$final_date, format = "%m/%d/%Y")
trial$final_date_monthyr <- format(trial$final_date, "%Y-%m")
trial$final_date_monthyr <- as.character(trial$final_date_monthyr)

approve <- read.csv("Data/EAD 3.0 Monthly_11282023.csv")
approve <- subset(approve, approve$country_name == "Argentina")

approve$year <-  substring(approve$monthly, 1, 4)
approve$month <- substrRight(approve$monthly, 2)
approve$month <- gsub("[^0-9.-]", "", approve$month)
for(i in 1:nrow(approve)){
  approve$month[i] <- ifelse(nchar(approve$month[i]) == 1, paste(0, approve$month[i], sep=""), approve$month[i])}

approve$final_date_monthyr <- paste(approve$year, approve$month, sep="-")

trial <- merge(trial,approve, by="final_date_monthyr", all.x=TRUE)

trial$under_kirchner = 1 - trial$under_macri

r3 <- lm_robust(noconvict ~ under_kirchner*Approval_Smoothed + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year.x, 
                clusters = trial_ID)

r4 <- lm_robust(life_sentence ~ under_kirchner*Approval_Smoothed + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year.x, 
                clusters = trial_ID)

texreg::screenreg(list(r1, r2, r3, r4), include.ci = F, 
                  'tab-out/tabSI9.tex')

