df = readRDS('data/officer_df.rds') %>%  
  filter(is.na(outcomes) == F) %>% 
  filter(die == 0) %>%  
  mutate(years_na = as.numeric(is.na(mean_sentence) == T)) %>% 
  filter(years_na == 0)

writeLines(
etable(
  feols(c(max_sentence, mean_sentence, life) ~ 
          scale(repression_std) + changed_ever + (factor(maxrank) + 
                                                                                         
                                                    factor(maxlevel) + tenure + officer_branch), 
        data = df), 
  tex = T), 
'tab-out/tabSI3.tex'
)

