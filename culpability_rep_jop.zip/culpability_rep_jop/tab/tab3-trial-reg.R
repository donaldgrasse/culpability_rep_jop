packs <- c('dplyr', 'estimatr', 'texreg', 'stringr', 'ggplot2', 'ggthemes')
lapply(packs, require, character.only = T)

#1. data cleaning####

trial <- read.csv('data/trials_data_FOR_ANALYSIS.csv', header = T)
trial$defendant_birth_year[trial$defendant_ID==806] <- 1947
trial$life_sentence <- as.numeric(trial$defendant_outcome=="life", 1,0)
trial$presiding_judge_appt_pres <- relevel(as.factor(trial$presiding_judge_appt_pres), 
                                           ref = 'Carlos Menem')

#2. main results####

m1 <- lm_robust(defendant_age ~ presiding_judge_appt_pres + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

m2 <- lm_robust(noconvict ~ presiding_judge_appt_pres + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

m3 <- lm_robust(life_sentence ~ presiding_judge_appt_pres + presiding_judge_gender + presiding_judge_tenure, data =  trial, 
                fixed_effects = year, 
                clusters = trial_ID)

texreg::screenreg(list(m1, m2, m3), include.ci = F, 
                  file = 'tab-out/tab3-trial-reg.tex')

