

packs <- c('tidyverse', 'dplyr', 'estimatr', 'texreg', 
           'stringr', 'ggplot2', 'ggthemes', 
           'fixest', 'xtable','tmap', 'sf', 'grid', 'MASS')
new.packages <- packs[!(packs %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)

pack2 =  c('tidyverse', 'dplyr', 'estimatr', 'texreg', 
           'stringr', 'ggplot2', 'ggthemes', 
           'fixest', 'xtable','tmap', 'sf', 'grid', 
           'forcats', 'grid')
lapply(pack2, require, character.only = T)


setwd('~/Desktop/culpability_rep_jop')
