setwd('~/Desktop/culpability_rep_jop')
source('_pack.R')

list.files("fig-in", full.names = TRUE) %>% purrr::walk(source)
list.files("tab", full.names = TRUE) %>% purrr::walk(source)

rm(list=ls())
